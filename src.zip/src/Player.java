// Title: Player
// Purpose: To create a multiusible Player Class that will keep a players score
// Programmer: Steven Habra

public class Player {
	// Private Data
	private String name;
	private int score;
	
	// Default Constructor
	public Player() {
		name = "";
		score = 0;
	}
	
	// Fill Constructor
	public void Fill(String name, int score) {
		this.name = name;
		this.score = score;
	}
	
	// Sets and Gets
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int p) {
		this.score = p;
	}
	
	// To String
	public String toString() {
		return (name + "  --  " + score + " points");
	}
	
}
