// Title: Color Panel Hack (Should be named 'Interactive Panel')
// Purpose: To provide an interactive interface while properly running the game through various
// classes, functions, structures, and more.
// Programmer: Steven Habra

import javax.imageio.*;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class ColorPanelHack extends JPanel implements MouseListener {

	// Private Game Data (essential to the overall structure of the project)
	private String[] pics = new String[52];
	private Rectangle[] choices = new Rectangle[6];
	private Player p = new Player();
	
	// Other global variables
	// Objects to go on panel
	JLabel lbls = new JLabel();
	JLabel lblmid = new JLabel();
	JLabel lblscore = new JLabel();
	JLabel lbllet = new JLabel();
	Rectangle[] outcome = new Rectangle[6];
	BufferedImage bkgnd;
	// Variables for data manipulation
	char[] letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
	ArrayList<Integer> banned = new ArrayList<>();
	char curlet;
	int numright;
	int whichone = -1;
	int correctban = -1;
	// Timer declaration and instantiation
	Timer timer = new Timer();
	TimerTask task = new Helper();
	
	// Default Constructor
	public ColorPanelHack(String name) throws IOException, UnsupportedAudioFileException, LineUnavailableException {
		addMouseListener(this); // Adds a mouse listener to the panel
		// Fills an array with the paths to the different images
		int count = 0;
		for (int i = 0; i < 52; i+=2) {
			pics[i] = "images\\" + Character.toString((char)(count+65)) + 1 + ".jpg";
			pics[i+1] = "images\\" + Character.toString((char)(count+65)) + 2 + ".jpg";
			count++;
		}
		// Initialize bkgnd
		bkgnd = ImageIO.read(new File("images\\abc.png"));
		// Set Player Data
		p.setScore(0);
		p.Fill(name, 0);
		// Set and Configure Label Options
		lbls.setFont(new Font("Serif", Font.PLAIN, 48));
		lbls.setText("The Alaphabet Game");
		lbls.setBounds(430, 0, lbls.getPreferredSize().width, lbls.getPreferredSize().height);
		lblscore.setText("Player:  " + name + "  ||  Score:  " + p.getScore());
		lblscore.setFont(new Font("Serif", Font.PLAIN, 18));
		lblscore.setBounds(540, 60, lblscore.getPreferredSize().width + 100, lblscore.getPreferredSize().height);
		lblmid.setFont(new Font("Serif", Font.PLAIN, 24));
		lblmid.setText("Choose all pictures with the letter:");
		lblmid.setBounds(480, 350, lblmid.getPreferredSize().width, lblmid.getPreferredSize().height);
		lbllet.setFont(new Font("Serif", Font.PLAIN, 128));
		//Initialize the player's answer choices 
		choices[0] = new Rectangle(100, 100, 275, 233, Color.black);
		choices[1] = new Rectangle(500, 100, 275, 233, Color.black);
		choices[2] = new Rectangle(900, 100, 275, 233, Color.black);
		choices[3] = new Rectangle(100, 625, 275, 233, Color.black);
		choices[4] = new Rectangle(500, 625, 275, 233, Color.black);
		choices[5] = new Rectangle(900, 625, 275, 233, Color.black);
		newround(); // Queues the first round
		// Add the labels to the panel
		add(lbls);
		add(lblscore);
		add(lblmid);
		add(lbllet);
		// Starts timer
		timer.schedule(task, 0, 500);
	}
	
	// Paint Component (The funciton that is responsible for data-visual connection)
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(bkgnd, 0, 0, null);
		for (int i = 0; i < 6; i++) {
			choices[i].fill(g);
		}
	}
	
	// Newround -- Used when a new letter and selection of choices needs to occur
	private void newround() throws IOException, UnsupportedAudioFileException, LineUnavailableException {
		// Checks to see if play has completed all 26 letters
		if (banned.size() == 26) {
			win();
		}
		else {
			int num;
			ArrayList<Integer> banned2 = new ArrayList<>();
			Boolean flag = false;
			correctban = -1;
			// Clears all background colors from previous round
			for (int i = 0; i < 6; i++) {
				choices[i].setColor(Color.black);
			}
			// Generates a unique random number from 0-25 (unique meaning hasn't been generated this game)
			do {
				flag = false;
				num = (int)(Math.random() * (letters.length));
				for (int i = 0; i < banned.size(); i++) {
					if (num == banned.get(i)) {
						flag = true;
						break;
					}
				}
			} while (flag);
			banned.add(num); 		// Adds it to the banned list
			curlet = letters[num];	// Finds corresponding letter
			// Decides how many correct answers will be on this next round and changes the pictures in choices
			numright = (int)(Math.random() * (2) + 1);
			for (int i = 0; i < numright; i++) {
				choices[i].newPic(pics[num*2 + i]);
			}
			// Adds correct options to a separate banned list
			banned2.add(2*num);
			banned2.add(2*num + 1);
			// Fills remaining slots with unique incorrect options (with no chance of accidentally picking a correct
			// option if there is only one correct answer on the board)
			for (int i = numright; i < 6; i++) {
				int num2;
				Boolean flag2 = false;
				do {
					flag2 = false;
					num2 = (int)(Math.random() * (52));
					for (int j = 0; j < banned2.size(); j++) {
						if (num2 == banned2.get(j)) {
							flag2 = true;
							break;
						}
					}
				} while (flag2);
				banned2.add(num2);
				choices[i].newPic(pics[num2]);
			}
			// Shuffles the choices and outputs the new letter
			shuffle(choices);
			lbllet.setText(Character.toString(curlet));
			lbllet.setBounds(600, 400, lbllet.getPreferredSize().width, lbllet.getPreferredSize().height);
		}
	}
		
	// Mouse Listener
	public void mouseReleased(MouseEvent e) {
		// Collects Mouse Coordinates
		double x = e.getX();
		double y = e.getY();
		// Finds which choice you selected
		for (int i = 0; i < 6; i++) {
			if (choices[i].containsPoint((int)x, (int)y)) {
				whichone = i;
				break;
			}
		}
		// Checks to see if you chose a unique correct answer
		if (whichone >= 0 && correctban != whichone && choices[whichone].getPath().substring(7, 8).equals(Character.toString(curlet))) {
			int temp = whichone;
			// Updates Color and Score
			choices[whichone].setColor(Color.green);
			p.setScore(p.getScore() + 50);
			repaint();
			whichone = -1;
			numright--;
			// Checks to see if there are any more correct answers on the board
			if (numright == 0) {
				whichone = -2;
				try {
					// Plays a nice job sound
					AudioInputStream nicejob = AudioSystem.getAudioInputStream(new File("audio\\Great Job.wav").getAbsoluteFile());
					Clip clip = AudioSystem.getClip();
					clip.open(nicejob);
					clip.start();
				} catch (UnsupportedAudioFileException | IOException e1) {e1.printStackTrace();} catch (LineUnavailableException e1) {e1.printStackTrace();}
			}
			else if (correctban != temp){
				System.out.println(correctban + "   " + temp);
				try {
					// Plays a sparkle sound
					AudioInputStream sparkle = AudioSystem.getAudioInputStream(new File("audio\\Fairy Sparkle.wav").getAbsoluteFile());
					Clip clip = AudioSystem.getClip();
					clip.open(sparkle);
					clip.start();
				} catch (UnsupportedAudioFileException | IOException e1) {e1.printStackTrace();} catch (LineUnavailableException e1) {e1.printStackTrace();}
			}
			correctban = temp;
			System.out.println(correctban);
		}
		else if (whichone >= 0 && correctban != whichone){
			// Updates Score
			p.setScore(p.getScore() - 10);
			repaint();
		}
	}
	
	// Shuffle Method
	private Rectangle[] shuffle(Rectangle[] r) {
		Rectangle temp;
		for (int i = 0; i < r.length; i++) {
			int rnum = (int)(Math.random() * (6));
			temp = r[i];
			r[i] = r[rnum];
			r[rnum] = temp;
		}
		return r;
	}
	
	// Win Function
	public void win() throws IOException, UnsupportedAudioFileException, LineUnavailableException {
		// Plays Applause
		AudioInputStream yay = AudioSystem.getAudioInputStream(new File("audio\\Small Applause.wav").getAbsoluteFile());
		Clip clip = AudioSystem.getClip();
		clip.open(yay);
		clip.start();
		// Clears Board
		removeAll();
		for (int i = 0; i < 6; i++) {
			choices[i] = new Rectangle(0,0,0,0, Color.black);
		}
		// Changes Background
		bkgnd = ImageIO.read(new File("images\\finish.png"));
		// Outputs a personalized congrats message w/ final score achieved
		JLabel j = new JLabel();
		j.setText("Congrats " + p.getName() + "!");
		j.setFont(new Font("Serif", Font.PLAIN, 96));
		j.setBounds(300, 100, j.getPreferredSize().width + 100, j.getPreferredSize().height);
		add(j);
		JLabel j2 = new JLabel();
		j2.setText("Your final score was " + p.getScore());
		j2.setFont(new Font("Serif", Font.PLAIN, 48));
		j2.setBounds(425, 225, j2.getPreferredSize().width, j2.getPreferredSize().height);
		add(j2);
		repaint();
	}
		
	// Helper Class
	private class Helper extends TimerTask{
		boolean bool = true;
		public void run() {
			// Depending on the value of "whichone" the timer will alter the background color of the answer chosen
			// First two options (if/elseif) make the background of the answer chosen flash red 
			if (whichone >=0 && correctban != whichone && bool) {
				choices[whichone].setColor(Color.red);
				bool = false;
				try {
					// Plays try again sound effect
					AudioInputStream tryagain = AudioSystem.getAudioInputStream(new File("audio\\Try Again.wav").getAbsoluteFile());
					Clip clip = AudioSystem.getClip();
					clip.open(tryagain);
					clip.start();
				} catch (UnsupportedAudioFileException | IOException e) {e.printStackTrace();} catch (LineUnavailableException e) {e.printStackTrace();}
			}
			else if (!bool){
				choices[whichone].setColor(Color.black);
				whichone = -1;
				bool = true;
			}
			// Third Option makes the background of the answer chosen flash green, and then begins a new round
			else if (whichone <= -2) {
				if (whichone == -3) {
					try {
						newround();
					} catch (IOException e) {e.printStackTrace();} catch (UnsupportedAudioFileException e) {e.printStackTrace();
					} catch (LineUnavailableException e) {e.printStackTrace();}
				}
				whichone--;
			}
			lblscore.setText("Player:  " + p.getName() + "  ||  Score:  " + Integer.toString(p.getScore()));
			repaint();
		}
	}
	
	
	// Unused Mouse Listeners, but required to be present
	public void mouseClicked(MouseEvent arg0) {}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {}
}
