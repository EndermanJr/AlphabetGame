// Title: FirstClassHackTest (should be named 'Alphabet Game')
// Purpose: To provide a main function that creates the proper java swing objects in order for ColorPanelHack
// to run correctly.
// Programmer: Steven Habra

import javax.swing.*;
import java.awt.*;
import java.io.*;
import javax.sound.sampled.*;

public class FirstClassHackTest {

	public static void main(String[] args) throws IOException, UnsupportedAudioFileException, LineUnavailableException {
		// Outputs Rules in I/O Terminal and will not proceed until they are acknowledged
		System.out.print(
			"Hello! Welcome to the Alphabet Game!\n\n" + 
			"The purpose of the Alphabet Game is to help elementary students develop and strengthen the relationship\n" +
			"of the alphabet's letters and real world objects, ultimately making them form conenctions quicker in\n" +
			"early childhood development.\n\n" +
			"How to Play:\n" + 
			"The game will begin by showing 6 objects stationed around the edge of the screen. A letter will also be\n" +
			"displayed in the middle. You will need to select all the objects that begin with the specified letter.\n" +
			"There will be either 1 or 2 correct answers. Once selected correctly, it will automatically move you on\n"+
			"to the next letter.\n\n" +
			"Have Fun!");
		
		boolean bool = false;
		do {
			if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog (null, "Have you read the directions outline in the I/O Terminal?","Instructions", JOptionPane.YES_NO_OPTION)) {
	        	bool = true;
				// Gathers User Name
	        	String n = JOptionPane.showInputDialog(null, "Enter your name. The game will continue with or without it.", "Ex: Steven");
			
	        	// Plays background music
	        	AudioInputStream bckgndmusic = AudioSystem.getAudioInputStream(new File("audio\\Lo-Fi Background Music.wav").getAbsoluteFile());
	        	Clip clip = AudioSystem.getClip();
	        	clip.open(bckgndmusic);
	        	clip.start();
	        	
	        	// Creates swing objects in proper order and relation and begins game 
	        	JFrame win1 = new JFrame();
	        	win1.setTitle("Alphabet Game");
	        	win1.setSize(1300, 1000);
	        	win1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        	ColorPanelHack c = new ColorPanelHack(n);
	        	c.setLayout(null);
	        	Container pain = win1.getContentPane();
	        	pain.add(c);
	        	win1.setVisible(true);
	        }
	        else {
	        	JOptionPane.showConfirmDialog(null, "Please do so", "Instructions", JOptionPane.PLAIN_MESSAGE);
	        }
		} while (!bool);
	}
}