// Title: Rectangle
// Purpose: To bind a Rectangle with a Buffered Image
// Programmer: Steven Habra

import java.awt.*;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Rectangle {
	// Private Data
	private Color color;
	private int centerx, centery, w, h;
	private BufferedImage image;
	private String path;
	
	// Fill Constructor
	public Rectangle(int x, int y, int w, int h, Color c) {
		centerx = x;
		centery = y;
		this.w = w;
		this.h = h;
		color = c;
	}
	// Way to change picture
	public void newPic(String path) throws IOException {
		this.path = path;
		image = ImageIO.read(new File(path));
	}
	// Draws filled in rectangle with overlayed picture
	public void fill(Graphics g) {
		Color oldColor = g.getColor();
		g.setColor(color);
		g.fillRect(centerx, centery, w, h);
		g.setColor(oldColor);
		g.drawImage(image, centerx, centery+26,null);
	}
	// Checks to see if a passed in point is within the rectangle
	public boolean containsPoint(int x, int y) {
		if (x > centerx && x < (centerx + w) && y > centery && y < (centery + h)) {
			return true;
		}
		else {
			return false;
		}
	}
	// Sets color
	public void setColor(Color c) {
		color = c;
	}
	// Returns path
	public String getPath() {
		return path;
	}
}
